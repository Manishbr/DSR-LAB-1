

#LAB1 PRGS

##---------OUTPUT-----------##
N1<-c(10,20,30,40,50)
str1<-c("water","mud","air")
R1<-c(10.5,20.5,30.6)
LL<-list(N1,str1,R1)

